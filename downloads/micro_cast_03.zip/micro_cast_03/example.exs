defmodule Example do
  def start do
    # with will exit and return result when one of these steps doesn't match {:ok, data}
    (with {:ok, data} <- step1(%{step1: nil, step2: nil, step3: nil}),
    {:ok, data} <- step2(data),
    do: step3(data))
    |> handle_result
  end

  defp handle_result({:ok, data}), do: IO.puts(inspect data)
  defp handle_result({:error, data}) do
    IO.puts "ERROR: #{inspect data}"
  end

  defp step1(data) do
    # return this to see the "error track"
    #{:error, %{data | step1: nil}}
    {:ok, %{data | step1: 1}}
  end

  defp step2(data) do
    {:ok, %{data | step2: data.step1 + 1}}
  end

  defp step3(data) do
    {:ok, %{data | step3: data.step2 * 2}}
  end
end

Example.start
