defmodule AvoidMocking do
  @inject %{
    puts: &IO.puts/1,
    another_thing: &Enum.filter/2
  }

  def hello_world(value, inject \\ @inject) do
    inject.puts.(value)
  end
end
