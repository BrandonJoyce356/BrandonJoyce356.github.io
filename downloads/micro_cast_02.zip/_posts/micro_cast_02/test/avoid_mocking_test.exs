defmodule AvoidMockingTest do
  use ExUnit.Case
  doctest AvoidMocking

  test "hello world" do
    test_value = "hello"
    AvoidMocking.hello_world(test_value, %{puts: &puts/1})
    assert_receive({:puts, "hello"})
  end

  defp puts(value) do
    send(self(), {:puts, value})
  end
end
